<?php
class Items{   
    
    private $itemsTable = "users";      
    public $id;
    public $name;
    public $description;
    public $price;
    public $category_id;   
    public $created; 
	public $modified; 
    private $conn;
	
    public function __construct($db){
        $this->conn = $db;
    }	
	
	function read(){	
		if($this->id) {
			$stmt = $this->conn->prepare("SELECT * FROM ".$this->itemsTable." WHERE user_id = ?");
			$stmt->bind_param("i", $this->id);					
		} else {
			$stmt = $this->conn->prepare("SELECT * FROM ".$this->itemsTable);		
		}		
		$stmt->execute();			
		$result = $stmt->get_result();		
		return $result;	
	}
	
	function create(){
		
		$stmt = $this->conn->prepare("
			INSERT INTO ".$this->itemsTable."('unique_id', 'Name', 'first_name', 'FullName', 'Email', 'Password', 'avatar', 'status', 'GroupId', 'RegStatus', 'Date')
			VALUES(?,?,?,?,?)");
		
		$this->unique_id = htmlspecialchars(strip_tags($this->unique_id));
		$this->Name = htmlspecialchars(strip_tags($this->Name));
		$this->first_name = htmlspecialchars(strip_tags($this->first_name));
		$this->FullName = htmlspecialchars(strip_tags($this->FullName));
		$this->Email = htmlspecialchars(strip_tags($this->Email));
		$this->Password = htmlspecialchars(strip_tags($this->Password));
		$this->avatar = htmlspecialchars(strip_tags($this->avatar));
		$this->status = htmlspecialchars(strip_tags($this->status));
		$this->GroupId = htmlspecialchars(strip_tags($this->GroupId));
		$this->RegStatus = htmlspecialchars(strip_tags($this->RegStatus));
		$this->Date = htmlspecialchars(strip_tags($this->Date));
		
		
		$stmt->bind_param("ssiis", $this->unique_id, $this->Name, $this->first_name, $this->FullName, $this->Email, $this->Password, $this->avatar, $this->status, $this->GroupId, $this->RegStatus, $this->Date);
		
		if($stmt->execute()){
			return true;
		}
	 
		return false;		 
	}
		
	function update(){
	 
		$stmt = $this->conn->prepare("
        UPDATE ".$this->itemsTable." SET Name = ?, Password = ?, Email = ?, tel = ?, FullName = ?, nationality = ?, careerlevel = ?, currentlocation = ?, currentposition = ?, currentcompany = ?, salary = ?, commitment = ?, noticeperiod = ?, visastatus = ?, highesteducation = ?, ageuser = ?, experionce = ?, genre = ?, birth = ? WHERE user_id = ?");
		$this->user_id = htmlspecialchars(strip_tags($this->user_id));
		$this->Name = htmlspecialchars(strip_tags($this->Name));
		$this->Password = htmlspecialchars(strip_tags($this->Password));
		$this->Email = htmlspecialchars(strip_tags($this->Email));
		$this->tel = htmlspecialchars(strip_tags($this->tel));
		$this->FullName = htmlspecialchars(strip_tags($this->FullName));
		$this->nationality = htmlspecialchars(strip_tags($this->nationality));
		$this->careerlevel = htmlspecialchars(strip_tags($this->careerlevel));
		$this->currentlocation = htmlspecialchars(strip_tags($this->currentlocation));
		$this->currentposition = htmlspecialchars(strip_tags($this->currentposition));
		$this->currentcompany = htmlspecialchars(strip_tags($this->currentcompany));
		$this->salary = htmlspecialchars(strip_tags($this->salary));
		$this->commitment = htmlspecialchars(strip_tags($this->commitment));
		$this->noticeperiod = htmlspecialchars(strip_tags($this->noticeperiod));
		$this->visastatus = htmlspecialchars(strip_tags($this->visastatus));
		$this->highesteducation = htmlspecialchars(strip_tags($this->highesteducation));
		$this->ageuser = htmlspecialchars(strip_tags($this->ageuser));
		$this->experionce = htmlspecialchars(strip_tags($this->experionce));
		$this->genre = htmlspecialchars(strip_tags($this->genre));
		$this->birth = htmlspecialchars(strip_tags($this->birth));
	 
		$stmt->bind_param("ssiisi", $this->user_id, $this->Name, $this->Password, $this->Email, $this->created, $this->tel,$this->FullName,$this->nationality,$this->careerlevel,$this->careerlevel,$this->currentlocation,$this->currentposition,$this->currentcompany,$this->salary,$this->commitment,$this->noticeperiod,$this->visastatus,$this->highesteducation,$this->ageuser,$this->experionce,$this->genre,$this->birth,$this->user_id);
		
		if($stmt->execute()){
			return true;
		}
	 
		return false;
	}
	
	function delete(){
		
		$stmt = $this->conn->prepare("
			DELETE FROM ".$this->itemsTable." 
			WHERE user_id = ?");
			
		$this->user_id = htmlspecialchars(strip_tags($this->user_id));
	 
		$stmt->bind_param("i", $this->user_id);
	 
		if($stmt->execute()){
			return true;
		}
	 
		return false;		 
	}
}
?>